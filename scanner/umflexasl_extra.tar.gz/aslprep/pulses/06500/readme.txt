pulse 06500
BIR8 pulse intended for velocity spectrum imaging. 
the control case and the label case are the same, but the control one encodes velocity as the sine(velocity) into the z axis.
the label case encodes velocity as the cosine of the velocity into the z axis.
first moment (m1) is 1.3e-5 sec^2
