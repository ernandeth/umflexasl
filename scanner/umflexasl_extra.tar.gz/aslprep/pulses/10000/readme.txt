BIR8 pulses for velocity spectrum: Label->cosine, Control->sine
Note: First gradient moment of the pulse is : 9.000000e-05 x Gmax (sec^2 * G/cm)
Vcut for 1.5 G/cm would be 8.698160e-01 : cm/s 
