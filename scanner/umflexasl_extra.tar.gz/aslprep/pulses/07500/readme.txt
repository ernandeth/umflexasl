BIR8 pulses for velocity spectrum: Label->cosine, Control->sine
Note: First gradient moment of the pulse is : 3.000000e-05 x Gmax (sec*G/cm)
Vcut for 1.5 G/cm would be 2.609448e+00 : cm/s 
