BIR8 pulses for velocity spectrum: Label->cosine, Control->sine
Note: First gradient moment of the pulse is : 5.100000e-05 x Gmax (sec*G/cm)
Vcut for 1.5 G/cm would be 1.534969e+00 : cm/s 
