FTVS pulse with 9 segments
the base pulse is a sinc achieving 90 degree tip angle of stationary spins
refosing pulses are composite 180's.  they follow an MLEV phase cycling scheme
