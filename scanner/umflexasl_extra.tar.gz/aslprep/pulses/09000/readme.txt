BIR8 pulses for velocity spectrum: Label->cosine, Control->sine
Note: First gradient moment of the pulse is : 6.300000e-05 x Gmax (sec^2 * G/cm)
Vcut for 1.5 G/cm would be 1.242594e+00 : cm/s 
